package com.course.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.course.beans.Course;
import com.course.exception.CourseException;
import com.course.repository.CourseRepository;


@Service
public class CourseServiceImpl implements CourseService {

	@Autowired
	private CourseRepository repository;
	
	
	public List<Course> addCourse(Course course) throws CourseException {
		if(repository.existsById(course.getCourseId())) {
			throw new CourseException("Course Id with " + course.getCourseId() + " already exists");
		}
		repository.save(course);
		
		return getAllDetails();
	}


	public List<Course> updateCourse(Course course) throws CourseException {
		if(repository.existsById(course.getCourseId())) {
		repository.save(course);
		return getAllDetails();
		}
		else {
			throw new CourseException("Course Id with "+ course.getCourseId() + " does not exist");
		}

		
	}
	public List<Course> deleteCourse(String id) throws CourseException{
		if(!repository.existsById(id)) {
			throw new CourseException("Course Id with " + id + " does not exist");
			
		}
		repository.deleteById(id);
		return getAllDetails();
		
	}


	public List<Course> getAllDetails() throws CourseException {
	    
		return repository.findAll();
	}


	public Course getAllDetailsById(String id) throws CourseException {
		if(!repository.existsById(id)) {
			throw new CourseException("Course Id with " + id + " does not exist");
		}
		
		
		return repository.findById(id).get();
		
	}


	public List<Course> getAllByModel(String mode) throws CourseException{
		if(mode.toLowerCase().equals("online")||mode.toLowerCase().equals("classroom")) {
			
			return repository.findAllByMode(mode);
		}
		else {
			throw new CourseException("Mode should not available");
		}
		
	}
	
	

}
