package com.course.service;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.course.beans.Course;
import com.course.exception.CourseException;

public interface CourseService {
	public List<Course> addCourse(Course course) throws CourseException;
	public List<Course> updateCourse(Course course) throws CourseException;
	public List<Course> deleteCourse(String  id) throws CourseException;
	public List<Course> getAllDetails() throws CourseException;
	public Course getAllDetailsById(String id) throws CourseException;
	public List<Course> getAllByModel(String mode) throws CourseException;

}
