package com.course.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.course.beans.Course;
import com.course.exception.CourseException;
import com.course.service.CourseServiceImpl;


@RestController
public class CourseController {
	
	@Autowired
    private CourseServiceImpl courseservice;

	@PostMapping("/courses")
	public List<Course> addCourse(@RequestBody  Course course) throws CourseException{
		return courseservice.addCourse(course);
		
	}
	
	
	@PutMapping("/courses/update")
	public List<Course> updateCourses(@RequestBody Course course) throws CourseException{
		return courseservice.updateCourse(course);
	}
	
	@DeleteMapping("/courses/{id}")
	public List<Course> deleteCourse(@PathVariable String id) throws CourseException{
		return courseservice.deleteCourse(id);
	}
	
	@RequestMapping("/courses")
	public List<Course> getAllDetails() throws CourseException{
		return courseservice.getAllDetails();
	}
	
	@GetMapping("/courses/{id}")
	public Course getAllDetailsById(@PathVariable String id) throws CourseException{
		return courseservice.getAllDetailsById(id);
		
		
	}
	
	
	@GetMapping("/courses/mode")
	public List<Course> getAllByMode(String mode) throws CourseException{
		return courseservice.getAllByModel(mode);
	}
	
	
	
	
}
