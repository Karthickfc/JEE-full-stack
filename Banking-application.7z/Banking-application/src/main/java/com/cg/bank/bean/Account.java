package com.cg.bank.bean;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

@Entity(name = "Account")

public class Account {
	@Id
	@SequenceGenerator(name = "accNumber",initialValue = 1000,allocationSize = 1)
	@GeneratedValue(generator = "accNumber",strategy = GenerationType.AUTO)
	private long accountNumber;
	private String accountHolderName;
	private double intialBalance;
	private double currentBalance;
	private String accountType;
	private long phoneNumber;
	/*
	 * @OneToMany(mappedBy = "Account",cascade = CascadeType.ALL,fetch =
	 * FetchType.LAZY) private List<Transaction> transaction=new
	 * ArrayList<Transaction>();
	 * 
	 * 
	 * public List<Transaction> getTransaction() { return transaction; }
	 * 
	 * public void setTransaction(List<Transaction> transaction) { this.transaction
	 * = transaction; }
	 */


	public Account(long accountNumber, String accountHolderName, double intialBalance, double currentBalance,
			String accountType, long phoneNumber, List<Transaction> transaction) {
		super();
		this.accountNumber = accountNumber;
		this.accountHolderName = accountHolderName;
		this.intialBalance = intialBalance;
		this.currentBalance = currentBalance;
		this.accountType = accountType;
		this.phoneNumber = phoneNumber;
		//this.transaction = transaction;
	}

	public long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}


	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	public double getIntialBalance() {
		return intialBalance;
	}

	public void setIntialBalance(double intialBalance) {
		this.intialBalance = intialBalance;
	}

	public double getCurrentBalance() {
		return currentBalance;
	}

	public void setCurrentBalance(double currentBalance) {
		this.currentBalance = currentBalance;
	}

	@Override
	public String toString() {
		return "Account [accountNumber=" + accountNumber + ", accountHolderName=" + accountHolderName
				+ ", intialBalance=" + intialBalance + ", currentBalance=" + currentBalance + ", accountType="
				+ accountType + ", phoneNumber=" + phoneNumber + /* ", transaction=" + transaction + */ "]";
	}

	public Account() {
		super();
	}
}
