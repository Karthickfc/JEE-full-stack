package com.cg.bank.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;

@Entity
public class Transaction {

	@Id
	@SequenceGenerator(name = "transId", initialValue = 1000, allocationSize = 1)
	@GeneratedValue(generator = "transId", strategy = GenerationType.AUTO)
	private long transactionId;
	private String transactionDescription;
	@ManyToOne
	private Account account;

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}


	public Transaction(long transactionId, String transactionDescription, Account account) {
		super();
		this.transactionId = transactionId;
		this.transactionDescription = transactionDescription;
		this.account = account;
	}

	public String getTransactionDescription() {
		return transactionDescription;
	}

	public void setTransactionDescription(String transactionDescription) {
		this.transactionDescription = transactionDescription;
	}

	@Override
	public String toString() {
		return "Transaction [transactionId=" + transactionId + ", transactionDescription=" + transactionDescription
				+ ", account=" + account + "]";
	}

	public Transaction() {
		super();
	}

}
