package com.cg.bank.exception;

@SuppressWarnings("serial")
public class AccountException extends Exception{

	public AccountException() {
		super();
	}
	public AccountException(String exception) {
		super(exception);
	}
}
