package com.cg.bank.bean;

public class Customer {
private String firstName;
private String middleName;
private String lastName;
private long mobileNumber;
private int pincode;
}
