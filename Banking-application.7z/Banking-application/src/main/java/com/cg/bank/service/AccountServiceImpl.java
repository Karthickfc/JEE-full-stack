package com.cg.bank.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bank.bean.Account;
import com.cg.bank.bean.Transaction;
import com.cg.bank.dao.AccountRepository;
import com.cg.bank.dao.TransactionRepository;
import com.cg.bank.exception.AccountException;
@Service
public class AccountServiceImpl implements AccountService{

	@Autowired
	private AccountRepository accountRepository;
	@Autowired
	private TransactionRepository transactionRepository;
	@Override
	public List<Account> createAccount(Account account) throws AccountException {
		double currBalance=0;
		Transaction transaction=new Transaction();
		List<Transaction>list=new ArrayList<Transaction>();
		double initialBalance=account.getIntialBalance()+currBalance;
		if(accountRepository.existsById(account.getAccountNumber())) {
			throw new AccountException("Account already exists...");
		}
		account.setCurrentBalance(initialBalance);
		accountRepository.save(account);
		transaction.setTransactionDescription("your account is created");
		list.add(transaction);
		//account.setTransaction(list);
		return getAllAccount();
	}

	@Override
	public List<Account> updateAccount(Account account) throws AccountException {
		if(accountRepository.existsById(account.getAccountNumber())) {
			
			accountRepository.save(account);
			return getAllAccount();
		}else {
			throw new AccountException("Account with id="+account.getAccountNumber()+" is not available.");
		}
	}

	@Override
	public List<Account> deleteAccount(long accNumber) throws AccountException {
		if(!accountRepository.existsById(accNumber)) {
			throw new AccountException("Account with id="+accNumber+"  doesn't exist");
		}
		accountRepository.deleteById(accNumber);
		return getAllAccount();
	}

	@Override
	public Account findAccountByAccountNumber(long id) throws AccountException {
		if(!accountRepository.existsById(id)) {
			throw new AccountException("Account with id="+id+"  doesn't exist");
		}
		return accountRepository.findById(id).get();
	}

	@Override
	public List<Account> getAllAccount() throws AccountException {
		try {
			return accountRepository.findAll();
		} catch (Exception e) {
			throw new AccountException(e.getMessage());
		}
	}


	@Override
	public Account withdraw(long accNumber, double amount) throws AccountException {
		if(accountRepository.existsById(accNumber)) {
			Account account=accountRepository.findById(accNumber).get();
			if (account.getCurrentBalance()>amount) {
				account.setCurrentBalance(account.getCurrentBalance()-amount);
				accountRepository.save(account);
			}else {
				throw new AccountException("The Account balance is less than the requested withdraw amount");
			}
			
		}
		else {
			throw new AccountException("Account doesn't exist");
		}
		return findAccountByAccountNumber(accNumber);
	}

	@Override
	public Account deposit(long accNumber, double amount) throws AccountException {
		if(accountRepository.existsById(accNumber)) {
			Account account=accountRepository.findById(accNumber).get();
				account.setCurrentBalance(account.getCurrentBalance()+amount);
				accountRepository.save(account);
				Transaction transaction=new Transaction();
				transaction.setTransactionDescription("your account "+accNumber+"is added with "+amount);
				transactionRepository.save(transaction);
		}
		else {
			throw new AccountException("Account doesn't exist");
		}
		return findAccountByAccountNumber(accNumber);
	}

	@Override
	public List<Account> tranferFund(long senderAccNumber,
			long receiverAccNumber,double amount) throws AccountException {
		Account senderAccount=accountRepository.findById(senderAccNumber).get();
		Account receiverAccount=accountRepository.findById(receiverAccNumber).get();
		if(accountRepository.existsById(senderAccNumber)) {
		if(accountRepository.existsById(receiverAccNumber)) {
			senderAccount.setCurrentBalance(senderAccount.getCurrentBalance()-amount);
			receiverAccount.setCurrentBalance(receiverAccount.getCurrentBalance()+amount);
			accountRepository.save(senderAccount);
			accountRepository.save(receiverAccount);
		}
		}
		return getAllAccount();
	}

}
