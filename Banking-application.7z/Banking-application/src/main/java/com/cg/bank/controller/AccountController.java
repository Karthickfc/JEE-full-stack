package com.cg.bank.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bank.bean.Account;
import com.cg.bank.exception.AccountException;
import com.cg.bank.service.AccountService;

@RestController
public class AccountController {

	@Autowired
	private AccountService accountService;

	@PostMapping("/create")
	public List<Account> createAccount(@RequestBody Account account) throws AccountException {
		return accountService.createAccount(account);
	}

	@PutMapping("/bank/update")
	public List<Account> updateAccount(@RequestBody Account account) throws AccountException {
		return accountService.updateAccount(account);
	}

	@DeleteMapping("/delete/{accNumber}")
	public List<Account> deleteAccount(@PathVariable long accNumber) throws AccountException {
		return accountService.deleteAccount(accNumber);
	}

	@GetMapping("/bank/{id}")
	public Account findAccountByAccountNumber(@PathVariable long id) throws AccountException {
		return accountService.findAccountByAccountNumber(id);
	}

	@RequestMapping("/bank")
	public List<Account> getAllAccount() throws AccountException {
		return accountService.getAllAccount();
	}

	@PutMapping("/bank/transfund/{senderAccNumber}/{receiverAccNumber}/{amount}")
	public List<Account> tranferFund(@PathVariable long senderAccNumber, @PathVariable long receiverAccNumber,
			@PathVariable double amount) throws AccountException {
		return accountService.tranferFund(senderAccNumber, receiverAccNumber, amount);
	}

	@PutMapping("/bank/withdraw/{accNumber}/{amount}")
	public Account withdraw(@PathVariable long accNumber, @PathVariable double amount) throws AccountException {
		return accountService.withdraw(accNumber, amount);
	}

	@PutMapping("/bank/deposit/{accNumber}/{amount}")
	public Account deposit(@PathVariable long accNumber, @PathVariable double amount) throws AccountException {
		return accountService.deposit(accNumber, amount);
	}
}