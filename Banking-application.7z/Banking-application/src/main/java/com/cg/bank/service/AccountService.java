package com.cg.bank.service;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.bank.bean.Account;
import com.cg.bank.exception.AccountException;

@Repository
public interface AccountService  {

	List<Account> createAccount(Account account) throws AccountException;
	List<Account> updateAccount(Account account) throws AccountException;
	List<Account> deleteAccount(long accNumber) throws AccountException;
	Account findAccountByAccountNumber(long id) throws AccountException;
	List<Account> tranferFund(long senderAccNumber,long receiverAccNumber,double amount) throws AccountException;
	List<Account> getAllAccount() throws AccountException;
	Account withdraw(long accNumber,double amount) throws AccountException;
	Account deposit(long accNumber,double amount) throws AccountException;
	
}
