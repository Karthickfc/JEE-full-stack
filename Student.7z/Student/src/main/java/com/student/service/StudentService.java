package com.student.service;

import java.util.List;

import com.student.beans.Student;
import com.student.exception.StudentException;

public interface StudentService {
	List<Student> addStudents(Student student) throws StudentException;
	
	List<Student> getAllStudents() throws StudentException;
	
    List<Student> updateStudent(Student student) throws StudentException;
    
    List<Student> deleteStudent(int id) throws StudentException;
    
    List<Student> getStudentByStream(String stream) throws StudentException;
	

 }
