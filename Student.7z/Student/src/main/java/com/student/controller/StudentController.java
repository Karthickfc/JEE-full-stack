package com.student.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.student.beans.Student;
import com.student.exception.StudentException;
import com.student.service.StudentServiceImpl;

@RestController
public class StudentController {
	
	@Autowired
	StudentServiceImpl studentServiceImpl;
	
	
	@PostMapping("/students")
	public List<Student> addStudent(@Valid @RequestBody Student student) throws StudentException{
		return studentServiceImpl.addStudents(student);
		
	}
	
	@RequestMapping("/students")
	public List<Student> getAllStudent() throws StudentException{
		return studentServiceImpl.getAllStudents();
	}
	
	@PutMapping("/students/update")
	public List<Student> updateStudent(@Valid  @RequestBody Student student) throws StudentException{
		return studentServiceImpl.updateStudent(student);
	}
	
	@DeleteMapping("/students/{id}")
	public List<Student> deleteStudent(@PathVariable int id) throws StudentException{
		return studentServiceImpl.deleteStudent(id);
		
	}
	
	@GetMapping("/students/stream")
	public List<Student> getStudentByStream(@RequestParam String stream) throws StudentException {
		return studentServiceImpl.getStudentByStream(stream);
	}
	
	
	

}
