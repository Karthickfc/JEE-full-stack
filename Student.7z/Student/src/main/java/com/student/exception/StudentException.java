package com.student.exception;

public class StudentException  extends Exception{
	public StudentException() {
		super();
	}
	public StudentException(String msg) {
		super(msg);
	}

}
