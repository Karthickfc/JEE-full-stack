import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Customer } from './Customer';
import { Merchant } from './Merchant';


@Injectable({
  providedIn: 'root'
})
export class UserService {
  private userUrl = 'http://localhost:6500/';
  customer: Customer;
  constructor(private http: HttpClient) {


  }

  detailsValidation(mailid: string) {
    return this.http.get<Customer>(this.userUrl + 'change/' + mailid);

  }
  resetPassword(resetPwd: string, mailId: string) {
    return this.http.get<Customer>(this.userUrl + 'reset/' + resetPwd + '/' + mailId);
  }
  changepwdDetailsValidation(mailid:string){
    return this.http.get<Customer>(this.userUrl + 'check/' + mailid );

  }

  merchantDetailsValidation(email:string){
    console.log(email);
    return this.http.get<Merchant>(this.userUrl + 'merchantchange/' + email);
  }
  resetMerchantPassword(resetpwd: string, email: string){
    return this.http.get<Merchant>(this.userUrl + 'resetMerchant/' + resetpwd + '/'  + email );
  }
  changeMerchantPwdDetailsValidation(email:string){
    return this.http.get<Merchant>(this.userUrl + 'checkMerchant?email=' + email);
  }







}
