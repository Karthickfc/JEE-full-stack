import { Component, OnInit } from '@angular/core';
import { Merchant } from '../Merchant';
import { UserService } from '../user.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-merchantchangepasswordcheck',
  templateUrl: './merchantchangepasswordcheck.component.html',
  styles: []
})
export class MerchantchangepasswordcheckComponent implements OnInit {

  merchant:Merchant;
  constructor(private userService:UserService,private route:ActivatedRoute,private router:Router) { }

  ngOnInit() {
  }
  checkMerchantChangePwd(checkData:string){
    this.userService.changeMerchantPwdDetailsValidation(checkData).subscribe(data=>{
      console.log(data);
      this.merchant=data;
      
      if(this.merchant!=null){
        setTimeout(()=>{
          this.router.navigateByUrl("merchantchangepasswordreset/" + this.merchant.email);
        },200)
      }
      else{
        alert('enter valid emailId');
      }
    }, (err) => alert('Enter valid emailId'));

  }

}
