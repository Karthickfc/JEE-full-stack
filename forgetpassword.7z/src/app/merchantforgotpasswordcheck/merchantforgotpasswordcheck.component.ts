import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { Merchant } from '../Merchant';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-merchantforgotpasswordcheck',
  templateUrl: './merchantforgotpasswordcheck.component.html',
  styles: []
})
export class MerchantforgotpasswordcheckComponent implements OnInit {

 merchant:Merchant;
  constructor(private userService:UserService,private router:Router) { }

  ngOnInit() {
  }
  checkMerchant(checkData:string){

    
    this.userService.merchantDetailsValidation(checkData).subscribe(data=>{
      console.log(data);
      this.merchant=data;
      
      if(this.merchant!=null){
        console.log(this.merchant.email)
        setTimeout(()=>{
          this.router.navigateByUrl("merchantforgotpasswordreset/" + this.merchant.email);
        },200)
        
      }
      else{
        alert('enter valid emailId');
      }
    }, (err) => alert('Enter valid emailId'));

  }

  }


