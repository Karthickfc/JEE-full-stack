export interface Customer{
     customerId:number;
     firstName:string;
     lastName:string;
     phone:string;
     emailId:string;
     password:string;


}