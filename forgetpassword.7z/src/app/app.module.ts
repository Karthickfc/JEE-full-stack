import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserService } from './user.service';
import { HttpClientModule } from "@angular/common/http";
import { ForgetpasswordcheckComponent } from './forgetpasswordcheck/forgetpasswordcheck.component';
import { ForgetpasswordresetComponent } from './forgetpasswordreset/forgetpasswordreset.component';
import { ChangepasswordcheckComponent } from './changepasswordcheck/changepasswordcheck.component';
import { ChangepasswordresetComponent } from './changepasswordreset/changepasswordreset.component';
import { MerchantforgotpasswordcheckComponent } from './merchantforgotpasswordcheck/merchantforgotpasswordcheck.component';
import { MerchantforgotpasswordresetComponent } from './merchantforgotpasswordreset/merchantforgotpasswordreset.component';
import { MerchantchangepasswordcheckComponent } from './merchantchangepasswordcheck/merchantchangepasswordcheck.component';
import { MerchantchangepasswordresetComponent } from './merchantchangepasswordreset/merchantchangepasswordreset.component';

@NgModule({
  declarations: [
    AppComponent,
    ForgetpasswordcheckComponent,
    ForgetpasswordresetComponent,
    ChangepasswordcheckComponent,
    ChangepasswordresetComponent,
    MerchantforgotpasswordcheckComponent,
    MerchantforgotpasswordresetComponent,
    MerchantchangepasswordcheckComponent,
    MerchantchangepasswordresetComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [UserService],
  bootstrap: [AppComponent]
})
export class AppModule { }
