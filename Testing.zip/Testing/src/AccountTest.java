import static org.junit.Assert.*;

import org.junit.Test;

public class AccountTest {
	
		@Test   
		public void tests1(){         
			Account tests = new Account(101, "savings", 0);      
			boolean actual =tests.deposit(-100);     
			assertFalse(actual);     
			}     
		@Test    
		public void tests2(){         
			Account tests1 = new Account(102, "savings", 0);      
			boolean actual = tests1.deposit(1500);      
			assertTrue(actual);    
			}    

	}


