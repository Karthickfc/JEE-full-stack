package com.cg;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;

public class MyBeanFactoryPostProcess implements BeanFactoryPostProcessor{

	@Override
	public void postProcessBeanFactory(ConfigurableListableBeanFactory beenfactory) throws BeansException {
		System.out.println("BeanFactory Processor");
		Point p =(Point)beenfactory.getBean("point2");
	}

}
