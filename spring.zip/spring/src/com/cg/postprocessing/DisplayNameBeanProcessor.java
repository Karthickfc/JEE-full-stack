package com.cg.postprocessing;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;

import com.cg.autowiring.Point;

public class DisplayNameBeanProcessor implements BeanPostProcessor{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	@Override
	public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
		// TODO Auto-generated method stub
	//	return BeanPostProcessor.super.postProcessAfterInitialization(bean, beanName);
		if(beanName.equals("point")){
			((Point)bean).setX(150);
			((Point)bean).setY(200);
		}
		System.out.println("Post process After Initialization"+beanName);
		return bean;
	}

	@Override
	public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
		System.out.println("Post process before Initialization"+beanName);
		return bean;
	}

}
