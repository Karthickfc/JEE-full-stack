package com.cg;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Mainapp2 {
public static void main(String[] args) {
	ApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
	Triangle2_Innerbean triangle=(Triangle2_Innerbean) context.getBean("triangle");
	triangle.draw();

}
}
