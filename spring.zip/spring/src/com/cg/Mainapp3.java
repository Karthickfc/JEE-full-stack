package com.cg;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Mainapp3 {
	public static void main(String[] args) {
		
	ApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
	Triangle3_collection triangle=(Triangle3_collection) context.getBean("triangle");
	triangle.draw();
	((AbstractApplicationContext) context).close();
	}

}
