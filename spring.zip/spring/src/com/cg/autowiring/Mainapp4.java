package com.cg.autowiring;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Mainapp4 {
@SuppressWarnings("resource")
public static void main(String[] args) {
	AbstractApplicationContext context=new ClassPathXmlApplicationContext("spring_autowiring.xml");
	context.registerShutdownHook();
	Circle circle=(Circle)context.getBean("circle");
	
	circle.draw();
	
}
}
