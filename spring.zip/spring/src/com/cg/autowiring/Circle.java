package com.cg.autowiring;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

import com.cg.Point;

public class Circle implements BeanNameAware,BeanFactoryAware,ApplicationContextAware,InitializingBean,DisposableBean{
private Point center;

public Point getCenter() {
	return center;
}

public void setCenter(Point center) {
	this.center = center;
}
public void draw(){
	System.out.println("circle points: ("+center.getX()+","+center.getY()+")");
}
public void myinit(){
	System.out.println("started");
}
public void teardown(){
	System.out.println("custom destroy Destroyed");
}

@Override
public void setBeanName(String beanName) {
	System.out.println("Bean name aware:"+beanName);
}

@Override
public void setBeanFactory(BeanFactory beanFactoryName) throws BeansException {
	System.out.println("Bean factory name aware:"+beanFactoryName);
}

@Override
public void setApplicationContext(ApplicationContext appcontextName) throws BeansException {
	System.out.println("Bean application name aware:"+appcontextName);
}

@Override
public void afterPropertiesSet() throws Exception {
	System.out.println("Initializing bean after properties set");
}

@Override
public void destroy() throws Exception {
	System.out.println("System destroy");
}
}
