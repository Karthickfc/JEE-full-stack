package org.capg.demo.service;

import java.util.List;

import org.capg.demo.beans.Employee;
import org.capg.demo.exception.EmployeeException;

public interface EmployeeService {
	
	List<Employee> getAllEmployees() throws EmployeeException;
	List<Employee> addEmployee(Employee emp) throws EmployeeException;
	Employee getEmployeeById(int id) throws EmployeeException;
	List<Employee> deleteEmployee(int id) throws EmployeeException;
	List<Employee> updateEmployee(Employee emp) throws EmployeeException;

}
