package com.capgemini;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

public class MainApp {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		EntityManagerFactory factory= Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		
		TypedQuery<Employee> typedquery= em.createNamedQuery("getAllEmployees", Employee.class);
		List<Employee> employees= typedquery.getResultList();
		for (Employee employee : employees) {
			System.out.println(employee);
			
		}
		
		
		
		System.out.println("-----------------------------------------------------------------------------");
		typedquery=em.createNamedQuery("getAllEmployeesByGender", Employee.class);
		typedquery.setParameter("gender", "Male");
		List<Employee> list=typedquery.getResultList();
		for (Employee employee : list) {
			System.out.println(employee);
		}
		
		
		
		/*System.out.println("Enter Employee Id");
		int empId=sc.nextInt();*/
		
		/*System.out.println("Enter Employee Gender");
		String empgender=sc.nextLine();
		System.out.println("Enter Employee Salary");
		float empSalary=sc.nextFloat();
		System.out.println("Enter Employee Age");
		int empAge=sc.nextInt();
		
		Query query =
				em.createQuery("update Employee set salary=salary+:s,age=age+:a where gender=:g");
		query.setParameter("s", empSalary);
		query.setParameter("a", empAge);
		query.setParameter("g", empgender);
		em.getTransaction().begin();
		int result = query.executeUpdate();
		em.getTransaction().commit();
		System.out.println(result + "rows are updated.");*/
		
		
		
		
		/*Query query= em.createQuery("update Employee set salary=salary+?,age=age+? where gender=?");
		query.setParameter(1, empSalary);
		query.setParameter(2, empAge);
		query.setParameter(3, empgender);
		em.getTransaction().begin();
		int result= query.executeUpdate();
		em.getTransaction().commit();
		System.out.println(result + " rows are updated.");*/
		
		
		
		
		/*TypedQuery<Employee> typedQuery= em.createQuery("from Employee where id=:eno", Employee.class);
		typedQuery.setParameter("eno", empId);
		
		Employee emp=typedQuery.getSingleResult();
		System.out.println(emp);*/
		
		
		
		
		
		
		/*Query query=em.createQuery("delete from Employee where id=:eno");
		query.setParameter("eno", empId);
		em.getTransaction().begin();;
		int result= query.executeUpdate();
		em.getTransaction().commit();
		System.out.println(result+" rows are updated");*/
		
		
		/*System.out.println("Enter Gender");
		String gender=sc.nextLine();*/
		
		
		//TypedQuery<Employee> typedquery= 
				/*em.createQuery("from Employee where gender=? ", Employee.class); // positional parameter
		typedquery.setParameter(1, gender); // 1 tells the position of the ? in above statement along with the input from the keyboard*/ 
				
		//em.createQuery("from Employee where gender=:empgender ", Employee.class);// :empgender is the reference variable where it is prefixed with : that is it means that it is a reference variable
		//typedquery.setParameter("empgender", gender);	// so here instead of using the position value use the reference variable name
		
		
		
		/*List<Employee> list= typedquery.getResultList();
		
		for (Employee employee : list) {
			System.out.println(employee);
			
		}*/
		
	}

}
