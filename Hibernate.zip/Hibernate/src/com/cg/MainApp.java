package com.cg;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class MainApp {
	public static void main(String[] args) {
		
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em= factory.createEntityManager();
		
		
		Employees emp=new Employees();
		emp.setName("vel");
		emp.setGender("Male");
		emp.setAge(24);
		emp.setSalary(5000);u
		em.getTransaction().begin();
		em.persist(emp);// inserts a row into the table
		
		
		
		/*Employee emp=new Employee(103,"Pushparaj","Male",21,22000);
		
		em.getTransaction().begin();
		em.persist(emp);
		em.getTransaction().commit();*/
		
		//em.getTransaction().begin();
		/*Employee emp=em.find(Employee.class, 103);//103 is primary key
		System.out.println(emp);*/
		/*emp.setSalary(70070);
		emp.setAge(22);*/
		
		/*Employee e=em.find(Employee.class, 102);
		Employee e1= em.find(Employee.class,101);		
		System.out.println(e);
		//em.detach(e);// gets the object from the persistence context(for the mentioned object only)
		em.clear();// gets the object from the persistence context without any object specification
		e.setAge(10);
		e1.setAge(55);*/
		
		
		//em.merge(e);// pulls the object from the detach
		
		/*em.remove(emp);*/
		em.getTransaction().commit();
		System.out.println("After commit");
		/*System.out.println(emp);*/
		
		
		
		System.out.println("Data Saved");
	}
}
