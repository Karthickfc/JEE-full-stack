package com.emp;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class MianApp {
	public static void main(String[] args) {
		EntityManagerFactory factor=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=factor.createEntityManager();
		
		Employee1 emp=new Employee1();
		emp.setName("Tanmay");
		
		TemporaryEmployee temp= new TemporaryEmployee();
		temp.setName("Shilpa");
		temp.setDailyWage(500);
		
		PermanentEmployee pemp= new PermanentEmployee();
		pemp.setName("Shivani");
		pemp.setAnnualSalary(56000);
		
		
		em.getTransaction().begin();
		em.persist(emp);
		em.persist(temp);
		em.persist(pemp);
		em.getTransaction().commit();
	
	}

}
