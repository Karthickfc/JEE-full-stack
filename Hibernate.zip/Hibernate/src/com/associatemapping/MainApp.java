package com.associatemapping;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class MainApp {
	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		
		
		
		//Faculty faculty= em.find(Faculty.class, 1);
		

		/*Faculty faculty = new Faculty();
		faculty.setName("Rahul");

		Technology technology = new Technology();
		technology.setTechnologyName("Java");
		faculty.setTechnology(technology);
		
		
		technology.setFaculty(faculty);*/
		
		/*Faculty faculty = new Faculty();
		faculty.setName("Rahul");

		Technology technology1 = new Technology();
		technology1.setTechnologyName("Java");
		
		
		Technology technology2 = new Technology();
		technology2.setTechnologyName("BDD");
		
		faculty.getTechnologies().add(technology1);
		faculty.getTechnologies().add(technology2);*/
		
		
		//technology.setFaculty(faculty);
		
		

		/*em.getTransaction().begin();

		em.persist(faculty);
		
		//em.persist(technology);

		em.getTransaction().commit();*/
		
		/*System.out.println(faculty);
		em.close();
		for (Technology tech : faculty.getTechnologies()) {
			System.out.println(tech);
			
		}*/
		
		
		
		
		Faculty faculty = new Faculty();
		faculty.setName("Rahul");

		
		
		
		Technology technology1 = new Technology();
		technology1.setTechnologyName("Java");
	
		
		
		Technology technology2 = new Technology();
		technology2.setTechnologyName("BDD");
		
		faculty.getTechnologies().add(technology1);
		faculty.getTechnologies().add(technology2);
		
		em.getTransaction().begin();
		
		
		em.getTransaction().commit();
		
		
		
		
		
		
		
		
		
		
	}

}
