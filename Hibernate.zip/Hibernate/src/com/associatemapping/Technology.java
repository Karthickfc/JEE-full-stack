package com.associatemapping;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

@Entity
public class Technology {
	@Id
	@GeneratedValue
	private int technologyId;
	private String technologyName;
	
	@ManyToOne
	private Faculty faculty;
	
	
	
	
	
	public Faculty getFaculty() {
		return faculty;
	}
	public void setFaculty(Faculty faculty) {
		this.faculty = faculty;
	}
	/*public Technology(int technologyId, String technologyName, Faculty faculty) {
		super();
		this.technologyId = technologyId;
		this.technologyName = technologyName;
		this.faculty = faculty;
	}
	public Faculty getFaculty() {
		return faculty;
	}
	public void setFaculty(Faculty faculty) {
		this.faculty = faculty;
	}*/
	@Override
	public String toString() {
		return "Technology [technologyId=" + technologyId + ", technologyName=" + technologyName  + /* ", faculty="
				+ faculty + */ " ] " ;
	}
	public int getTechnologyId() {
		return technologyId;
	}
	public void setTechnologyId(int technologyId) {
		this.technologyId = technologyId;
	}
	public String getTechnologyName() {
		return technologyName;
	}
	public void setTechnologyName(String technologyName) {
		this.technologyName = technologyName;
	}
	public Technology(int technologyId, String technologyName) {
		super();
		this.technologyId = technologyId;
		this.technologyName = technologyName;
	}
	public Technology() {
		super();
		// TODO Auto-generated constructor stub
	}

}
