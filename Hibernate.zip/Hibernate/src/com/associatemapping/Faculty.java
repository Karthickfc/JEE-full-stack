package com.associatemapping;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Faculty {
	@Id
	@GeneratedValue
	private int id;
	private String name;
	
	@OneToMany(cascade= CascadeType.ALL, mappedBy="faculty" )     //, fetch = FetchType.EAGER)
	/*@JoinTable(name="ft",joinColumns=@JoinColumn(name="facId"),inverseJoinColumns=@JoinColumn(name="techId"))*/
	private List<Technology> technologies= new ArrayList();
	
	
	
	
	
	/*@OneToOne(cascade = CascadeType.ALL)//,mappedBy = "faculty")
	@JoinColumn(name="technologyId")
	private Technology technology;*/
	
	public List<Technology> getTechnologies() {
		return technologies;
	}
	public void setTechnologies(List<Technology> technologies) {
		this.technologies = technologies;
	}
	/*public Faculty(int id, String name, Technology technology) {
		super();
		this.id = id;
		this.name = name;
		this.technology = technology;
	}*/
	/*public Technology getTechnology() {
		return technology;
	}
	public void setTechnology(Technology technology) {
		this.technology = technology;
	}*/
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Faculty(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	public Faculty() {
		super();
	}
	@Override
	public String toString() {
		return "Faculty [id=" + id + ", name=" + name + /*", technology=" + technology + "*/"]";
	}
	

}
