package com.cg.capstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.capstore.bean.Merchant;

@Repository
public interface MerchantRepository extends JpaRepository<Merchant, Integer> {

	@Query("from Merchant where email=:email")
	public Merchant findMerchantByMail(@Param("email") String email);
}
