package com.cg.capstore.service;

import com.cg.capstore.bean.Customer;
import com.cg.capstore.bean.Merchant;
import com.cg.capstore.exception.CustomerException;
import com.cg.capstore.exception.MerchantException;

public interface CustomerService {
	public Customer mailidCheck(String mailId) throws CustomerException;
	public Customer updatePassword(String newpwd,String mailId) throws CustomerException;
	public Customer checkEmailId(String mailId) throws CustomerException;
	public Merchant merchantMailIdCheck(String email) throws MerchantException;
	public Merchant updateMerchantPassword(String newpwd,String email) throws MerchantException;
	public Merchant checkMerchantEmail(String email) throws MerchantException;
	


}
