package com.cg.capstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.capstore.bean.Customer;
import com.cg.capstore.bean.Merchant;
import com.cg.capstore.dao.CustomerRepository;
import com.cg.capstore.dao.MerchantRepository;
import com.cg.capstore.exception.CustomerException;
import com.cg.capstore.exception.MerchantException;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	CustomerRepository repository;

	@Autowired
	MerchantRepository merchantRepository;

	@Override
	public Customer mailidCheck(String mailId) throws CustomerException {

		Customer customer = repository.findByMailId(mailId);

		if (customer.getMailId().equals(mailId)) {
			return customer;
		} else {
			throw new CustomerException("Invlaid mailId");
		}

	}

	@Override
	public Customer updatePassword(String newpwd, String mailId) throws CustomerException {

		Customer customer1 = repository.findByMailId(mailId);

		if (customer1.getPassword().equals(newpwd)) {
			return null;
		} else {
			customer1.setPassword(newpwd);
			repository.save(customer1);
			return customer1;
		}
	}

	@Override
	public Customer checkEmailId(String mailId) throws CustomerException {

		Customer customer = repository.findByMailId(mailId);

		if (customer.getMailId().equals(mailId)) {
			return customer;
		} else {
			throw new CustomerException("Invlaid mailId");
		}
	}

	@Override
	public Merchant merchantMailIdCheck(String email) throws MerchantException {

		Merchant merchant = merchantRepository.findMerchantByMail(email);

		if (merchant.getEmail().equals(email)) {

			return merchant;
		} else {
			throw new MerchantException("Invlaid mailId");
		}

	}

	@Override
	public Merchant updateMerchantPassword(String newpwd, String email) throws MerchantException {
		Merchant merchant = merchantRepository.findMerchantByMail(email);

		if (merchant.getPassword().equals(newpwd)) {
			return null;
		} else {
			merchant.setPassword(newpwd);
			merchantRepository.save(merchant);
			return merchant;
		}
	}

	@Override
	public Merchant checkMerchantEmail(String email) throws MerchantException {
		Merchant merchant = merchantRepository.findMerchantByMail(email);

		if (merchant.getEmail().equals(email)) {
			return merchant;
		} else {
			throw new MerchantException("Invlaid mailId");
		}
	}

}
