package com.cg.capstore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.capstore.bean.Customer;
import com.cg.capstore.bean.Merchant;
import com.cg.capstore.exception.CustomerException;
import com.cg.capstore.exception.MerchantException;
import com.cg.capstore.service.CustomerServiceImpl;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class CustomerController {

	@Autowired
	private CustomerServiceImpl service;

	@GetMapping("/change/{mailId}")
	public Customer getEmailId(@PathVariable("mailId") String mailId) throws CustomerException {
		System.out.println(mailId);
		return service.mailidCheck(mailId);
	}

	@GetMapping("/reset/{newpwd}/{mailId}")
	public Customer updatePassword(@PathVariable("newpwd") String newpwd, @PathVariable("mailId") String mailId)
			throws CustomerException {
		System.out.println(newpwd + mailId);
		return service.updatePassword(newpwd, mailId);
	}

	@GetMapping("/check/{mailId}")
	public Customer checkEmailId(@PathVariable("mailId") String mailId) throws CustomerException {
		System.out.println(mailId);
		return service.mailidCheck(mailId);
	}

	@GetMapping("/merchantchange/{email}")
	public Merchant getMerchantEmailId(@PathVariable("email") String email) throws MerchantException {
		System.out.println(email);
		return service.merchantMailIdCheck(email);
	}

	@GetMapping("/resetMerchant/{newpwd}/{email}")
	public Merchant updateMerchantPassword(@PathVariable("newpwd") String newpwd, @PathVariable("email") String email)
			throws MerchantException {
		System.out.println(email + newpwd);
		return service.updateMerchantPassword(newpwd, email);
	}

	@GetMapping("/checkMerchant")
	public Merchant checkMerchantEmail(@RequestParam("email") String email) throws MerchantException {
		return service.checkMerchantEmail(email);
	}

}
