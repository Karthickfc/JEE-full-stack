package com.cg.capstore.exception;

public class CustomerException extends Exception{

	public CustomerException(String message) {
		super(message);
	}
}
