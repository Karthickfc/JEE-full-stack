package com.cg.capstore.bean;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.websocket.ClientEndpoint;

@Entity
public class Customer {

	@Id
	@SequenceGenerator(name = "cust_id", sequenceName = "cust_id", initialValue = 10000, allocationSize = 1)
	@GeneratedValue(generator = "cust_id")
	private int customerId;
	private String firstName;
	private String lastName;
	private String phone;
	private String mailId;
	private String password;

	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Customer(int customerId, String firstName, String lastName, String phone, String mailId, String password) {
		super();
		this.customerId = customerId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phone = phone;
		this.mailId = mailId;
		this.password = password;
	}

	@OneToMany
	private List<Address> addresses = new ArrayList<Address>();

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getMailId() {
		return mailId;
	}

	@Override
	public String toString() {
		return "CapStoreBean [customerId=" + customerId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", phone=" + phone + ", mailId=" + mailId + ", password=" + password + "]";
	}

	public void setMailId(String mailId) {
		this.mailId = mailId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
