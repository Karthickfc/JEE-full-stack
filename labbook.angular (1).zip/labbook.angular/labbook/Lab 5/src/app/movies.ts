export class Movies
{
    name:String;
    rating:number;
    genre:String;
}