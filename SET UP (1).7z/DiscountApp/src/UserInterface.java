
import java.util.Scanner;

public class UserInterface {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		int noOfProducts = sc.nextInt();
		String products[] = new String[noOfProducts];

		for (int i = 0; i < noOfProducts; i++) {
			products[i] = sc.next();
		}

		float dis1 = 2500.0f;
		String p1 = null;

		float dis2 = 250.0f;
		String p2 = null;
		for (int i = 0; i < noOfProducts; i++) {
			String[] sepP= products[i].split(",");

			float disc = (Integer.parseInt(sepP[1]) * Integer.parseInt(sepP[2])) / 100;
			System.out.println(disc);
			if (disc < dis1) {
				dis1 = disc;
				p1 = sepP[0];
			}

			else if (disc == dis1) {
				dis2 = disc;
				p2 = sepP[0];
			}
		}

		System.out.println(p1 + " " + dis1);

		if (dis2 == dis1) {
			System.out.println(p2 + " " + dis2);
		}

		sc.close();
	}

}
