import static org.junit.Assert.*;

import org.junit.Test;

public class EmployeeTest {
	@Test
	public void testcalNetPay() {
		Employee employee = new Employee(101,"pavan",2000,5);
		double actual = employee.calNetPay();
		double expected = 2000;
		assertTrue(expected==actual);
	}
	@Test
	public void testcalNetPay1() {
		Employee employee = new Employee(101,"pavan",1000,6);
		double actual = employee.calNetPay();
		double expected = 9400;
		assertTrue(expected==actual);
	}
}
