package com.ui;

import java.util.Scanner;

import com.bean.Call;
import com.utility.CallHistory;

public class UserInterface {
	
	public static void main(String a[]){
		Scanner scan=new Scanner(System.in);
		int n = 0;
		CallHistory callH = new CallHistory();
		System.out.println("Enter the call details");
		n = Integer.parseInt(scan.nextLine());
		System.out.println("Enter the student details");
		for (int i = 0; i < n; i++) {
			String details = scan.nextLine();
			Call call = new Call();
			call.parseData(details);
			callH.addCall(call);
		}
		System.out.println("Enter the grade");
		long time = scan.nextLong();
		System.out.println("Count:" + callH.findTotalDuration(time));
		scan.close();
	}

}
