import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AlbumsService {
  albums: any[] = [];
  constructor() { }
  addAlbum(data: any) {
    this.albums.push(data);
  }
  getAlbums(): any[] {
    return this.albums;
  }
}
