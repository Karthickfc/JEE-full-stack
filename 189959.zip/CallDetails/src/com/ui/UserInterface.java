package com.ui;

import java.util.Scanner;
import java.util.StringTokenizer;

import com.bean.Call;

public class UserInterface {
	static Call c1=new Call();
	public static void main(String a[]){
		Scanner sc=new Scanner(System.in);
		String details = sc.nextLine();
		
		c1.parseData(details);
		
		System.out.println(c1.getCalledNumber());
		
	}

	
}
