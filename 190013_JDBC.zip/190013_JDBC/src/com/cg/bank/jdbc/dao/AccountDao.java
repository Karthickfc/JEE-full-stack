package com.cg.bank.jdbc.dao;

import java.sql.Date;

import com.cg.bank.jdbc.bean.Account;
import com.cg.bank.jdbc.exception.AccountNotFoundException;
import com.cg.bank.jdbc.service.Transaction;

public interface AccountDao {
	public void insert(Account account);
	public void update(double balanceAmount, Integer accountNo);
	public void delete(Integer accountNo) throws AccountNotFoundException;
	public void transactionDetails(Transaction trans, Integer accountNo, Date date);
	public void query();
	

}
