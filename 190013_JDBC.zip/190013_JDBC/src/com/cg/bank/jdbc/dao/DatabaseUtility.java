package com.cg.bank.jdbc.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseUtility {
	
	final static String url="jdbc:oracle:thin:@localhost:1521:xe";
	final static String username= "INVENTORY1";
	final static String pwd = "INVENTORY1";
	static Connection con = null;
	
	public static Connection getConnection() throws SQLException{
		if(con!=null){
			return con;
		}
		else{
			try{
				Class.forName("oracle.jdbc.driver.OracleDriver");
				con = DriverManager.getConnection(url, username, pwd);
				
			}catch(ClassNotFoundException e){
				System.err.println(e.getMessage());
			}catch(SQLException e){
				System.err.println(e.getMessage());
			}
			return con;
		}
	}

}
