import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MyserviceService {

  http:HttpClient;
  employees:Employee[]=[];

  constructor(http:HttpClient) { 
    this.http=http;
    this.fetchEmployees();
  }

  fetched:boolean=false;

  fetchEmployees() 
  {
    this.http.get('./assets/employee.json')
    .subscribe(
      data=>
      {
        if(!this.fetched)
        {
          this.convert(data);
          this.fetched=true;
        }
      }
    );
  }

  getEmployees():Employee[]
  {
    return this.employees;
  }

  convert(data:any)
  {
    for(let o of data)
    {
      let e=new Employee(o.eid,o.ename,o.email,o.econtact);
      this.employees.push(e);
    }
  }
  
  delete(eid:number)
  {
    let foundIndex:number=-1;
    for(let i=0;i<this.employees.length;i++)
    {
      let e=this.employees[i];
      if(eid==e.eid)
      {
        foundIndex=i;
        break;
      }
    }
    this.employees.splice(foundIndex,1);
  }

  add(e:Employee){
    this.employees.push(e);
  }

}
export class Employee{
  eid:number;
  ename:string;
  email:string;
  
  econtact:number;
    constructor(eid:number,ename:string,email:string,econtact:number)
    {
      this.eid=eid;
      this.ename=ename;
      this.email=email;
      
      this.econtact=econtact;
    }
}